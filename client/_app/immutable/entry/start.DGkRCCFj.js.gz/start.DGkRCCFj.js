import{a as t}from"../chunks/entry.D3GAGzq2.js";export{t as start};
